package fr.florianmoreau.fonctionTest;

public class Main {

    public static void main(String[] args) {
        int money = 850;
        int pricePhone = 800;
        boolean hasPhone = false;

        renvoiMess("Fonction renvoiMess me lit ce message");
        renvoiMess("rigolo ! il te restera "+getRes(money, pricePhone, hasPhone)+" euro apres l achat du telephone"); //Utiliser une fonction dans une fonction
        renvoyeur("Chaine", 25);
        System.out.println("On est dans la fonction principal");
        sendMess(); //Affiche se que retourne la fonction void sendMess de la classe Main
        System.out.println(secondClass.getString()); //Affiche se que retourne la fonction getString de classe secondClass
    }

    /*
    public = Accessible partout
    protected = Accessible uniquement dans cette classe et les classes qui utilise cette fonction
    Static = acces direct à cette fonction sans charger la classe

    int retourne entier
    String retourne chaine de caractere
    boolean vrai ou faux
    toutes type de variable accepter dans le guetteur
    void = NE RETOURNE RIEN

    () sert a donner des parametres
    */

    //On test les fonction prive static void
    private static void sendMess(){//Accessible que dans cette classe
        System.out.println("Je suis dans la fonction void sendMess de la classe Main");
    }
    private static void renvoiMess(String message){//Accessible que dans cette classe
        System.out.println("lecture du message : "+message);
    }
    private static void renvoyeur(String mess, int nbr){
        System.out.println("La chaine de caractere : "+mess+" et voici le nombre entier : "+nbr);
    }

    //On test les fonction qui retourne quelques choses
    private static int getRes(int money, int pricePhone, boolean hasPhone){
        if(money >= pricePhone && !hasPhone){
            System.out.println("Tu peux acheter ce telephone");
        } else {
            System.out.println("Tu n as pas l argent necessaire pour te payer ce telephone ou/et tu la deja.");
        }

        return money - pricePhone;
    }
}
