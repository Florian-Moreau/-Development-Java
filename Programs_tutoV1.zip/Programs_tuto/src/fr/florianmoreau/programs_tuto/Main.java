package fr.florianmoreau.programs_tuto; //Package du programme

public class Main {  //Création de la classe publique Main. Classe principal

    public static void main(String[] args) { //Methode Main par défaut qui retourne rien (void)
        /*
        Le premiere exemple monte une condition
         */
        //Initialisation des variable
        int money = 850;
        int priceObject = 800;
        boolean hasObject = false;

        if (money >= priceObject && !hasObject){ //test si money et plus grand ou egal à priceObjet ET si hasObject est faux
            System.out.println("Tu peux acheter cet objet"); //Affiche du texte
        } else {
            System.out.println("Tu ne peux pas acheter cet objet et tu en as deja un");
        }

        /*
        Ce second exemple montre une creation d'un tableau de chaine de caractere et des comparaisons
         */

        String pseudo = "Root"; //Variable chaine de caractere
        String[] names = {"Luffy", "Naruto", "Koro", "Root", "lUfFy"}; //Tableau de chaine de caractere
        System.out.println(names[0]); //Affiche la premiere valeur du tableau

        if(names[0] == names[1]){ //Tes si la premire valeurs et egal a la deuxieme valeur du tableau
            System.out.println("Les deux valeurs sont identiques");
        } else {
            System.out.println("Les deux valeurs ne sont pas identiques");
        }

        if(names[3] == pseudo){ //Test si la 4eme valeur du tableau est egal a la variable pseudo
            System.out.println("Les deux valeurs sont identiques");
        } else {
            System.out.println("Les deux valeurs ne sont pas identiques");
        }

        if(names[0].equalsIgnoreCase(names[4])){ //verifie en ignorant les majuscules et minuscules
            System.out.println("Les deux valeurs sont identiques");
        } else {
            System.out.println("Les deux valeurs ne sont pas identiques");
        }

        /*
        Ce troisieme exemple montre un tableau avec des entiers ainsi que des calculs
         */

        int[] nombres = {18, 5, 18, 14, 16};
        int calcul = (nombres[0] + nombres[1] + nombres[2] + nombres[3] + nombres[4]) / nombres.length; // Moyenne des valeurs du tableaux
        System.out.println ("il y a "+nombres.length+" valeurs dans le tableau"); //Donne le nombre de valeur dans le tableau nombres
        System.out.println("La moyenne des valeurs est de : "+calcul);

        /*
        Des tableaux dans des tableaux
         */

        int[][] nbr = { //Cela creer des sous tableaux dans un tableau
                {
                    4, 6, 9
                },
                {
                    2, 3, 4
                },
                {
                    1, 5, 7
                },
        };
        System.out.println("Valeurs : "+nbr[0][2]); //Dans le tableau nbr, dans le premier sous tableau 0, je veux la 3eme valeur soit 2

        /*
        Convertir chaine de caractere en tableau
         */

        String prenom = "Florian,Bob,Smirnouf";
        String[] prenomTabl = prenom.split(","); //Le split delimite la variable prenom par le caractere entre quote. ici virgule
        System.out.println("Il y a "+prenomTabl.length+" dans ce tableau");

        /*
        Les boucles
         */

        //La boucle pour (for)
        for(int i = 0; i < 10; i++){ //Pour i partant de 0. Tant qu'il est strictement inférieur à 100, faire i+1 ainsi que les actions situer dans la boucle
            System.out.println("Tour numero "+ i);
        }

        //La boucle foreach, utilisé pour les objets tableaux etc
        for (String str : prenomTabl){
            System.out.println(str);
        }
        //Second foreach pour calculer moyenne de note dans un tableau
        int[] notes = {15, 19, 5, 12};
        int moy = 0;
        for(int noteTabl : notes){ //Pour un tableau de entier on passe chaque entier du tableau notes
            moy = moy + noteTabl;
        }
        System.out.println("La moyenne du tableau est de : "+(moy / notes.length)); //Calcul la moyenne

        /*
        Boucle tant que (while)
         */

        int x = 0;
        while(x != 5){
            System.out.println("Hello World");
            x++;
        }
        boolean verif = false;
        while(verif == false){
            System.out.println("La verification est fausse");
            verif = true;
        }
        System.out.println("La verification est juste");

        /*
        Le do while. Boucle s execute au moins une fois car il boucle puis fait le test
         */
        int y = 0;
        do{ //Demarre la boucle
            System.out.println("Je passe une fois dans do");
            y++;
        } while(y != 2); //repete la boucle si la condition est confirmé
    }
}
