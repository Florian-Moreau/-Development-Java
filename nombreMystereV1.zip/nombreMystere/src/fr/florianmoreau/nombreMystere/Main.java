/*
* Programme : nombreMystere
* Action : Genere un nombre aleatoire et l'utilisateur doit le deviner
* Auteur : Florian MOREAU
* dd/mm/yyyy : 13/09/2018
* */

package fr.florianmoreau.nombreMystere;

//Ceci importe la classe Scanner du package java.util
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        //Initialisation des variables
        Scanner sc = new Scanner(System.in); //Initialisation du scanner de clavier
        int choice, min=0, max=10; //Choix, minimum, maximum
        String nbrUsed = " ";
        int res = min + (int)(Math.random() * ((max - min) + 1)); //Le nombre aleatoire a trouver
        int round=1; //Compteur de tour

        System.out.println("Bienvenue dans le jeu du nombre mystere ! \n");
        System.out.println("Tour n "+round+"\n");
        System.out.println("Veuillez saisir un nombre entre "+min+" et "+max+" : ");
        choice = sc.nextInt();
        nbrUsed = nbrUsed+" | "+choice+" | ";

        if (choice == res){
            System.out.println("Du premier coup ! Vous etes une machine !");
            sc.close();
        }
        else {
            while(choice != res) {
                round++; //ajoute 1 au nombre de tour (variable round)
                if (choice > res) {
                    System.out.println("Tour n "+round+"\n");
                    System.out.println("Vous avez deja repondu : "+nbrUsed+"\n");
                    System.out.println("Fail ! Le nombre est plus PETIT que "+choice+"\n");
                    System.out.println("Veuillez saisir un nombre entre "+min+" et "+max+" : ");
                    choice = sc.nextInt();
                    nbrUsed = nbrUsed+" | "+choice+" | ";
                }
                else if (choice < res) {
                    System.out.println("Tour n " + round + "\n");
                    System.out.println("Vous avez deja repondu : "+nbrUsed+"\n");
                    System.out.println("Fail ! Le nombre est plus GRAND que " + choice + "\n");
                    System.out.println("Veuillez saisir un nombre entre " + min + " et " + max + " : ");
                    choice = sc.nextInt();
                    nbrUsed = nbrUsed+" | "+choice+" | ";
                }
            }
            System.out.println("GG ! En "+round+" tours.\n");
            System.out.println("Voici vos reponses : "+nbrUsed);
            sc.close();
        }
    }
}