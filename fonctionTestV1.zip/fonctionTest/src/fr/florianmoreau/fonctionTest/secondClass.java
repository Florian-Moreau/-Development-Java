package fr.florianmoreau.fonctionTest;

public class secondClass {

    public static String getString(){
        String message = "Je suis une fonction dans secondClass";
        return message;
    }
}
